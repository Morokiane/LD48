# LD48
Ludem Dare 48 Compo - Buried Deep

As a dog your most proud moment is having found the Golden Bone. You diligently buried in the yard, only to find the hole uncover and a deep chasm where it once was. Go after and find your prize.

Contols:
A gamepad is reccomended.
Gamepad Controls - Left and Right D-Pad will move the character. A is jump. B will exit Game Over screens.
Keyboard Controls - Left and Right arrows will move the character. Z is jump. X will exit Game Over screens.
Gameplay:
Hearts - You start with two hearts and have a maxium of three. Collecting a heart in the dungeon will fill all your hearts back to 3.
Bones - Collecting three bones will give you one heart. If you have three hearts and three bones you will be unable to collect new bones until you lose a heart. At this point collecting a forth point will convert three bones into a heart
Keys - You will need keys to access areas through locked doors.

Have fun and good luck on this little platformer!!
